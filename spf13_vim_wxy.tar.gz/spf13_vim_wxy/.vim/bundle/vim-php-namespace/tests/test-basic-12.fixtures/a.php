<?php

namespace Foo;

abstract class Bar {
}

