""" Description. """

# Module information
# ==================


__version__ = "2.1.1"
__project__ = "pylama_pylint"
__author__ = "horneds <horneds@gmail.com>"
__license__ = "BSD"

from .main import Linter  # noqa
