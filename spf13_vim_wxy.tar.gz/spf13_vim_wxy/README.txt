本目录包含了很多隐藏文件

使用方法:
    执行 install.sh 脚本
    ./install.sh
    将所有隐藏文件全部覆盖拷贝到家目录

注意:
    neocomplete requires Vim 7.3.885 or later with Lua support ("+lua").
    vim需要更新到 7.3.885 版本及以上,vim编译时需要lua的支持。
    通过 vim --version 可以查看vim 的版本以及是否由lua支持。
